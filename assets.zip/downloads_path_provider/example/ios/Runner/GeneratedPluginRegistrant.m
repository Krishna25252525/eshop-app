//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<downloads_path_provider_28/DownloadsPathProviderPlugin.h>)
#import <downloads_path_provider_28/DownloadsPathProviderPlugin.h>
#else
@import downloads_path_provider_28;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [DownloadsPathProviderPlugin registerWithRegistrar:[registry registrarForPlugin:@"DownloadsPathProviderPlugin"]];
}

@end
