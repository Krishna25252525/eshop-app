# downloads_path_provider_28_example

Demonstrates how to use the downloads_path_provider_28 plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
