## 0.0.1

* Plugin implemented for Android

## 0.0.2

* Added instructions for the required `AndroidManifest.xml` permissions


## 0.1.0

* iOS support added
