final String appName = 'eShop Multivendor';

final String packageName = 'wrteam.eshop.multivendor';
final String androidLink = 'https://play.google.com/store/apps/details?id=';

final String iosPackage = 'wrteam.eshop.multivendor';
final String iosLink = 'your ios link here';
final String appStoreId = '123456789';

final String deepLinkUrlPrefix = 'https://eshopmultivendor.page.link';
final String deepLinkName = 'eshop';

final int timeOut = 50;
const int perPage = 10;

final String baseUrl = 'https://vendor.eshopweb.store/app/v1/api/';

final String jwtKey = "68f05dec6014f68e760c5c5fa3e31bcf391a2e10";
